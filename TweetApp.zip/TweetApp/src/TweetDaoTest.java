import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.tweet.app.start.TweetDao;
import com.tweet.app.start.Tweets;
import com.tweet.app.start.UserDao;

public class TweetDaoTest {
	
	TweetDao tweetDao;
	@Test
	void insertTweet() {
		Tweets tweet = new Tweets();
		tweet.setEmail_id("Sriraksha.a@gmail.com");
		tweet.setTweets("Hello Test");
		boolean expVal = true;
		boolean val = TweetDao.insertTweet(tweet);
		assertEquals(expVal, val);
	}
	
	
	@Test
	void getAllTweets() {
		Tweets tweet = new Tweets();
		tweet.setEmail_id("Santhosh.a@gmail.com");
		
		List<String> expRes = Arrays.asList("Java has many features", "Functional Interface is a new feature in Java");

		List<String>  val = TweetDao.getAllTweets(tweet);
		assertEquals(expRes, val);
	}

}
