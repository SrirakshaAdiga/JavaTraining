import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.tweet.app.start.User;
import com.tweet.app.start.UserDao;

public class UserDaoTest {

	  UserDao dao;
	
	@Test
	void insertRecord() {
		User user = new User();
		user.setFname("Rinil");
		user.setEmaid_id("Rinil@gamil.com");
		user.setPassword("Volvo123");
		user.setStatus("");
		boolean expVal = true;
		boolean val = UserDao.insertRecord(user);
		assertEquals(expVal, val);
	}
	
	@Test
	void verifyUser() {
		User user = new User();
		user.setEmaid_id("Suresh@gamil.com");
		user.setPassword("Lap123");
		String expVal = "valid";
		String val = UserDao.verifyUser(user);
		assertEquals(expVal, val);
	}
	
	@Test
	void updatePassword() {
		User user = new User();
		user.setEmaid_id("Santhosh.a@gmail.com");
		user.setPassword("Incorrect157");
		String expVal = "validPassword";
		String val = UserDao.updatePassword(user);
		assertEquals(expVal, val);
	}
	@Test
	void checkIfPasswordSame() {
		User user = new User();
		user.setEmaid_id("Sriraksha.a@gmail.com");
		user.setPassword("Nov123");
		boolean expVal = false;
		boolean val = UserDao.checkIfPasswordSame(user);
		assertEquals(expVal, val);
	}
	
//	@Test
//	void insertTweet() {
//		Tweets tweet = new Tweets();
//		tweet.setEmail_id("Sriraksha.a@gmail.com");
//		tweet.setTweets("Hello Test");
//		boolean expVal = true;
//		boolean val = UserDao.insertTweet(tweet);
//		assertEquals(expVal, val);
//	}
//	
//	
//	@Test
//	void getAllTweets() {
//		Tweets tweet = new Tweets();
//		tweet.setEmail_id("Santhosh.a@gmail.com");
//		
//		List<String> expRes = Arrays.asList("Java has many features", "Functional Interface is a new feature in Java");
//
//		List<String>  val = UserDao.getAllTweets(tweet);
//		assertEquals(expRes, val);
//	}
	
	
	
}
