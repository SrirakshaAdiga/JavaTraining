package com.tweet.app;

import com.tweet.app.start.TweetAppInitializer;

public class TweetMainApp {

	public static void main(String[] args) {
		TweetAppInitializer  tweetapp= new TweetAppInitializer();
		tweetapp.DisplayMenuForGuestUser();
		tweetapp.MenuAction();

	}

}
