package com.tweet.app.start;

import java.sql.Connection;
import java.sql.DriverManager;

public class CreateConnection {
static Connection con;
public static Connection createc() {
	try {
		
	
	 final String dburl = "jdbc:mysql://localhost:3306/tweetdb";
	 final String user = "root";
	 final String pwd = "pass@word1";
	con = DriverManager.getConnection(dburl, user, pwd);
	}catch(Exception e) {
		e.printStackTrace();
	}
	return con;

	}
}
