package com.tweet.app.start;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

	static final String query = "insert into User (fname,email_id,password,status) values (?,?,?,?)";

	public static boolean insertRecord(User user) {
		boolean f = false;
		try {
			Connection con = CreateConnection.createc();
			String query = "insert into User (fname,email_id,password,status) values (?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, user.getFname());
			ps.setString(2, user.getEmaid_id());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getStatus());
			ps.executeUpdate();
			f = true;

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return f;
	}

	public static String verifyUser(User user) {
		String value = "NotValid";
		try {
			Connection con = CreateConnection.createc();
			Statement st = con.createStatement();
			String query = "select * from User where email_id ='" + user.getEmaid_id() + "' and password= '"
					+ user.getPassword() + "'";
			ResultSet rs = st.executeQuery(query);
			if (rs.next()) {
				String Password = rs.getString("password");
				if (user.getPassword().equals(Password)) {
					value = "valid";
					changeStatus(user);
				} else {
					value = "InvalidPassword";
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return value;
	}

	public static void changeStatus(User user) {
		try {
			Connection con = CreateConnection.createc();
			String query = "update user SET status = ? where email_id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setString(1, user.getStatus());
			ps.setString(2, user.getEmaid_id());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public static String updatePassword(User userss) {
	String validPaasword = "NotvalidPaasword";
	boolean val = checkIfPasswordSame(userss);
	if(val) {
		try {
			Connection con = CreateConnection.createc();
			String query = "update user SET password = ? where email_id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setString(1, userss.getPassword());
			ps.setString(2, userss.getEmaid_id());
			ps.executeUpdate();
			validPaasword = "validPassword";
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}else {
		return validPaasword;
	}
		return validPaasword;
	}

	public static boolean checkIfPasswordSame(User userss) {
		boolean f = false;
		try {
			Connection con = CreateConnection.createc();
			Statement st = con.createStatement();
			String query = "select * from User where email_id ='" + userss.getEmaid_id() + "' ";
			ResultSet rs = st.executeQuery(query);
			if (rs.next()) {
				String Password = rs.getString("password");
				if (!userss.getPassword().equals(Password)) {
					f = true;
				} else {
					f = false;
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return f;
	}

//	public static boolean insertTweet(Tweets tweets) {
//	
//		boolean tweet = false;
//		try {
//			Connection con = CreateConnection.createc();
//			String query = "insert into tweet (email_id,tweets) values (?,?)";
//			PreparedStatement ps = con.prepareStatement(query);
//			ps.setString(1, tweets.getEmail_id());
//			ps.setString(2, tweets.getTweets());
//			
//			ps.executeUpdate();
//			tweet = true;
//
//		} catch (SQLException e) {
//			e.printStackTrace();
//
//		}
//		return tweet;
//	}
//
//	public static List<String> getAllTweets(Tweets tweeet) {
//		List<String> posts = new ArrayList<>();
//		try {
//			Connection con = CreateConnection.createc();
//			Statement st = con.createStatement();
//			String query = "select * from tweet where email_id ='" + tweeet.getEmail_id() + "'";
//			ResultSet rs = st.executeQuery(query);
//			while(rs.next()) {
//				posts.add(rs.getString("tweets"));
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		if (posts!=null && !posts .isEmpty()) {
//			return posts;
//			
//		}else {
//			return null;
//			}
//	}
//
//	public static List<String> getAllUserTweets(String emaid) {
//		List<String> posts = new ArrayList<>();
//		try {
//			Connection con = CreateConnection.createc();
//			Statement st = con.createStatement();
//			String query = "select * from tweet where email_id ='" + emaid + "'";
//			ResultSet rs = st.executeQuery(query);
//			while(rs.next()) {
//				posts.add(rs.getString("tweets"));
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		if (posts!=null && !posts .isEmpty()) {
//			return posts;
//			
//		}else {
//			return null;
//			}
//		
//	}

	public static void changeStatus(String emaid_id, String logoutStatus) {
		try {
			Connection con = CreateConnection.createc();
			String query = "update user SET status = ? where email_id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setString(1, logoutStatus);
			ps.setString(2, emaid_id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
