package com.tweet.app.start;

public class User {
	public User() {
		super();
	}

	private String fname;
	private String emaid_id;
	private String password;
	private String status;

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getEmaid_id() {
		return emaid_id;
	}

	public void setEmaid_id(String emaid_id) {
		this.emaid_id = emaid_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User(String fname, String emaid_id, String password, String status) {
		super();
		this.fname = fname;
		this.emaid_id = emaid_id;
		this.password = password;
		this.status = status;
	}

	@Override
	public String toString() {
		return "User [fname=" + fname + ", emaid_id=" + emaid_id + ", password=" + password + ", status=" + status
				+ "]";
	}

}
