package com.tweet.app.start;

public class Tweets {
	private String email_id;
	private String tweets;

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getTweets() {
		return tweets;
	}

	public void setTweets(String tweets) {
		this.tweets = tweets;
	}

	public Tweets(String email_id, String tweets) {
		super();
		this.email_id = email_id;
		this.tweets = tweets;
	}

	public Tweets() {
		super();
	}

	@Override
	public String toString() {
		return "Tweets [email_id=" + email_id + ", tweets=" + tweets + "]";
	}

}
