package com.tweet.app.start;
import java.util.List;
import java.util.Scanner;

public class TweetAppInitializer {

	int ch;
	String again;
	
	User users;
	Scanner sc = new Scanner(System.in);

	public void DisplayMenuForGuestUser() {
		System.out.println("**********Introduction Menu for Guest user**********");
		System.out.println("	1.Register	");
		System.out.println("	2.Login	");
		System.out.println("	3.Forgot Password	");
	}
	public void DisplayMenuForLoggedUser() {
		System.out.println("**********Menu for Logged in user**********");
		System.out.println("	4.Post a tweet	");
		System.out.println("	5.View my tweet	");
		System.out.println("	6.View all tweets	");
		System.out.println("	7.Reset Password	");
		System.out.println("	8.Logout	");
	}

	public void MenuAction() {
		while(true) {
		System.out.println("**Enter your Choice**");
		ch = sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("Enter FirstName");
			String fName = sc.next();
			System.out.println("Enter Email_Id");
			String emaid_id = sc.next();
			System.out.println("Enter Password");
			String password = sc.next();
			String status = "";
			User user = new User(fName,emaid_id,password,status);
			boolean inserted = UserDao.insertRecord(user);
			if(inserted) {
			System.out.println("Sucessfully Registerd, Please login to access application");
			DisplayMenuForGuestUser();
			}else {
				System.out.println("Error while Registering");
			}
			

			break;
		case 2: 
			System.out.println("Enter FirstName");
			String firstName = sc.next();
			System.out.println("Enter Email_Id");
			String emaiD_id = sc.next();
			System.out.println("Enter Password");
			String passworD = sc.next();
			String statuss = "True";
			 users = new User(firstName,emaiD_id,passworD,statuss);
			String value = UserDao.verifyUser(users);
			if(value.equals("valid")) {
				System.out.println("You Have Sucessfully Logged in");	
				DisplayMenuForLoggedUser();
			}else if (value.equals("InvalidPassword")){
				System.out.println("Invalid Password, Please Try again");
				DisplayMenuForGuestUser();
			}else if(value.equals("NotValid")){
				System.out.println("User not found, Please register yourself");
				DisplayMenuForGuestUser();
			}
			break;
		case 3:
			System.out.println("Enter Email_Id");
			String emaid_ID = sc.next();
			System.out.println("Enter New Password");
			String newPassword = sc.next();
			User userss = new User();
			userss.setEmaid_id(emaid_ID);
			userss.setPassword(newPassword);
			String validPaasword = UserDao.updatePassword(userss);
			if(validPaasword.equals("validPassword")) {
				System.out.println("You Have Sucessfully changed password");	
				DisplayMenuForLoggedUser();
			}else if (validPaasword.equals("NotvalidPaasword")) {
				System.out.println("Either Incorrect Email or password given is old password, Please try again");
				DisplayMenuForGuestUser();
			}
			
			break;
		case 4:
			System.out.println("Post a tweet");
			sc.nextLine();
			String tweet = sc.nextLine();
			Tweets tweets = new Tweets(users.getEmaid_id(),tweet);
			boolean post = TweetDao.insertTweet(tweets);
			if(post) {
				System.out.println("Thank you for the post");
				DisplayMenuForLoggedUser();
			}else {
				System.out.println("Issue while posting, Please try again");
				DisplayMenuForLoggedUser();
			}
			break;
		case 5:
			Tweets tweeet = new Tweets();
			 tweeet.setEmail_id(users.getEmaid_id());
			//boolean view = UserDao.getAllTweets(tweeet);
			 List<String> posts =  TweetDao.getAllTweets(tweeet);
			 if(posts!=null) {
				 System.out.println("Below are your tweets: "+ '\n' + posts);
				 DisplayMenuForLoggedUser();
			 }else {
				 System.out.println("No tweets yet, Please select option to post a tweet");
				 DisplayMenuForLoggedUser();
			 }
			break;
		case 6:
			System.out.println("Enter the emailid you wish to view");
			String emaid = sc.next();
			List<String> postsOfAllUser =  TweetDao.getAllUserTweets(emaid);
			 if(postsOfAllUser!=null) {
				 System.out.println("Below are your tweets: "+ '\n' + postsOfAllUser);
				 DisplayMenuForLoggedUser();
			 }else {
				 System.out.println("No tweets yet for the entered email");
				 DisplayMenuForLoggedUser();
			 }
			break;
		case 7:
			System.out.println("Enter Email_Id");
			String emaid_IDs = sc.next();
			System.out.println("Enter New Password");
			String newPasswords = sc.next();
			User userrss = new User();
			userrss.setEmaid_id(emaid_IDs);
			userrss.setPassword(newPasswords);
			String validPaaswords = UserDao.updatePassword(userrss);
			if(validPaaswords.equals("validPassword")) {
				System.out.println("You Have Sucessfully Reset your password");	
				DisplayMenuForLoggedUser();
			}else if (!validPaaswords.equals("NotvalidPaasword")) {
				System.out.println("Either Incorrect Email or password given is old password, Please try again");
				DisplayMenuForLoggedUser();
			}
			break;
		case 8:
			System.out.println("Thank you for Using Application..." +'\n');
			String LogoutStatus = "False";
			UserDao.changeStatus(users.getEmaid_id(),LogoutStatus);
			System.out.println(" If you want to login again...Please choose the option");
			DisplayMenuForGuestUser();
			break;

		default:
			break;
		}
		
//		System.out.println("You have logged out of application");
//	    System.out.println("Do you want to login again (Y/N");
//		again=sc.next();
//		if(again.equalsIgnoreCase("Y")) {
//			DisplayMenuForGuestUser();
//		}else if(again.equalsIgnoreCase("N")) {
//				System.out.println("Do you want to login again (Y/N");
//			}
		}
		}

	}


