package com.tweet.app.start;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TweetDao {
	public static boolean insertTweet(Tweets tweets) {
		
		boolean tweet = false;
		try {
			Connection con = CreateConnection.createc();
			String query = "insert into tweet (email_id,tweets) values (?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, tweets.getEmail_id());
			ps.setString(2, tweets.getTweets());
			
			ps.executeUpdate();
			tweet = true;

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return tweet;
	}

	public static List<String> getAllTweets(Tweets tweeet) {
		List<String> posts = new ArrayList<>();
		try {
			Connection con = CreateConnection.createc();
			Statement st = con.createStatement();
			String query = "select * from tweet where email_id ='" + tweeet.getEmail_id() + "'";
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				posts.add(rs.getString("tweets"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (posts!=null && !posts .isEmpty()) {
			return posts;
			
		}else {
			return null;
			}
	}

	public static List<String> getAllUserTweets(String emaid) {
		List<String> posts = new ArrayList<>();
		try {
			Connection con = CreateConnection.createc();
			Statement st = con.createStatement();
			String query = "select * from tweet where email_id ='" + emaid + "'";
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				posts.add(rs.getString("tweets"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (posts!=null && !posts .isEmpty()) {
			return posts;
			
		}else {
			return null;
			}
		
	}

}
