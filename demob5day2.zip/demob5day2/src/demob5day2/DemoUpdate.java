package demob5day2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoUpdate {
	static final String dburl = "jdbc:mysql://localhost:3306/testdb";
	static final String user = "root";
	static final String pwd = "pass@word1";
	
	static final String query = "update Student SET stud_lname = ? where student_id = ?"; 
	
	
	public static void main(String[] args) {
		try(Connection con = DriverManager.getConnection(dburl, user, pwd);
				PreparedStatement ps = con.prepareStatement(query);
				){
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Student ID");
			int sid=sc.nextInt();
			System.out.println("Enter Student Last name");
			String lname=sc.next();
			
			ps.setInt(2, sid);
			ps.setString(1, lname);
			ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
