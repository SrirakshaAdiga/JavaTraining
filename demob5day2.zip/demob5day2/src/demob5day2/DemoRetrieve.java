package demob5day2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DemoRetrieve {
	static final String dburl = "jdbc:mysql://localhost:3306/testdb";
	static final String user = "root";
	static final String pwd = "pass@word1";
	static final String query = "select * from Student";
	

	public static void main(String[] args) {
		try(Connection con = DriverManager.getConnection(dburl, user, pwd);
				Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
				){
		
		
			while(rs.next()) {
				System.out.println("student_id = " +rs.getInt("student_id"));
				System.out.println("stud_fname = " +rs.getString("stud_fname"));
				System.out.println("stud_lname= "+ rs.getString("stud_lname"));
				System.out.println("city= "+rs.getString("city") );
			}
		}catch(SQLException e) {
				e.printStackTrace();
			}
	}
}
		

		
	

