package demob5day2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoInsert {
	static final String dburl = "jdbc:mysql://localhost:3306/testdb";
	static final String user = "root";
	static final String pwd = "pass@word1";
	static final String query = "insert into Student (student_id,stud_fname,stud_lname,city) values (?,?,?,?)";

	public static void main(String[] args) {
		try(Connection con = DriverManager.getConnection(dburl, user, pwd);
				PreparedStatement ps = con.prepareStatement(query);
				){
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Student ID");
			int sid=sc.nextInt();
			System.out.println("Enter Student First name");
			String fname=sc.next();
			System.out.println("Enter Student Last name");
			String lname=sc.next();
			System.out.println("Enter Student city");
			String city=sc.next();
			
			ps.setInt(1, sid);
			ps.setString(2, fname);
			ps.setString(3, lname);
			ps.setString(4, city);
			ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
	

	}
	}
}
