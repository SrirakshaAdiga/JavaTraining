package demob5day2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DemoSearchById {
	static final String dburl = "jdbc:mysql://localhost:3306/testdb";
	static final String user = "root";
	static final String pwd = "pass@word1";
	
	//static final String query = "select * from Student  where student_id = ?"; 
	
	
	public static void main(String[] args) {
		try{Connection con = DriverManager.getConnection(dburl, user, pwd);
				Statement st = con.createStatement();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Student ID");
			int sid=sc.nextInt();
			String query = "select * from Student  where student_id = '"+sid+"'"; 
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				System.out.println("student_id = " +rs.getInt(1));
				System.out.println("stud_fname = " +rs.getString(2));
				System.out.println("stud_lname= "+ rs.getString(3));
				System.out.println("city= "+rs.getString(4) );
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
