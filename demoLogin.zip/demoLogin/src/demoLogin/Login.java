package demoLogin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Login {
	static final String dburl = "jdbc:mysql://localhost:3306/tweetdb";
	static final String user = "root";
	static final String pwd = "pass@word1";
	static final String query = "select * from user where email_id = ? AND password = ?";

	public static void main(String[] args) {
	try(Connection con = DriverManager.getConnection(dburl, user, pwd);
			Statement st = con.createStatement();
			PreparedStatement ps = con.prepareStatement(query);
			){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter email");
		String email_id=sc.next();
		System.out.println("Enter Password");
		String password=sc.next();
		
		
		ps.setString(1, email_id);
		ps.setString(2, password); 
		
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			System.out.println("Sucessfully logged in");
		}else {
			System.out.println("Login failed");
		}
	}catch(SQLException e) {
		e.printStackTrace();
		
	}
}

}
