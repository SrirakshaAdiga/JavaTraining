package demoLogin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Registration {
	static final String dburl = "jdbc:mysql://localhost:3306/tweetdb";
	static final String user = "root";
	static final String pwd = "pass@word1";
	static final String query = "insert into User (fname,email_id,password,status) values (?,?,?,?)";

	public static void main(String[] args) {
	try(Connection con = DriverManager.getConnection(dburl, user, pwd);
			PreparedStatement ps = con.prepareStatement(query);
			){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter FirstName");
		String fname=sc.next();
		System.out.println("Enter email");
		String email_id=sc.next();
		System.out.println("Enter Password");
		String password=sc.next();
		System.out.println("Enter status");
		String status=sc.next();
		
		ps.setString(1, fname);
		ps.setString(2, email_id);
		ps.setString(3, password);
		ps.setString(4, status);
		ps.executeUpdate();
	}catch(SQLException e) {
		e.printStackTrace();
		
	}
}
}
