import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class DemoStream {
	
	public static void  main(String[] args) {
		List<Integer> num = Arrays.asList(5,2,7,8,4,3);
		num.forEach(a->System.out.println(a));
		Stream<Integer> da = num.stream();
		
		Stream<Integer> sort = da.sorted();
		sort.forEach(a->System.out.print(a));
	}

}
